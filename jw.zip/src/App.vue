<template>
  <div id="app">

    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style scoped>

@import "./styles/global.css";
@import "./styles/global.min.css";
</style>

